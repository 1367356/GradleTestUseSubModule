package com.li;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.li.dao.mapper")
public class SpringBootSpringSecurityApplication {
    public static void main(String[] args){
        SpringApplication.run(SpringBootSpringSecurityApplication.class, args);
    }
}
