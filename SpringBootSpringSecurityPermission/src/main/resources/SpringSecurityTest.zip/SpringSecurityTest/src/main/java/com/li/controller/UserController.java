package com.li.controller;

import com.li.dao.User;
import com.li.service.UserService;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ResourceNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;
import java.util.Map;

@Controller
public class UserController {

    @Autowired
    UserService userService;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String login() {
        System.out.println("home");
        return "forum/home";
    }

    @RequestMapping(value = "/user/login", method = RequestMethod.GET)
    public String displayLoginPage(Model model) {
        System.out.println("进入");
        model.addAttribute("title", "用户登陆");
        return "forum/user-login"; //登录界面，验证没通过。
    }

    /**
     * 用户注册
     * @param model
     * @return
     */
    @RequestMapping(value = "/user/registration", method = RequestMethod.GET)
    public String showRegistrationPage(Model model) {
        System.out.println("registrationGet");
        model.addAttribute("userDto", new User());
        return "forum/user-registration";  //注册页面
    }

    @RequestMapping(value = "/user/registration", method = RequestMethod.POST)  //提交注册
    public String registerNewUser(@ModelAttribute("userDto") User user,BindingResult bindingResult,
                                  Model model, HttpServletRequest request) {
        System.out.println("registrationPost");
        Map<String, Object> attributes = this.userService.registerUserAccount(user);
        model.addAllAttributes(attributes);
        return "forum/user-registration-result";
    }


    @PreAuthorize("hasAuthority('SUPER')")  //需要SUPER用户才能通过该路径，第一步通过配置验证，没有用户登录，将会拦截，让用户登录，登录成功，访问该路径时进行角色验证。
    @RequestMapping(value = "/admin/admin", method = RequestMethod.GET)
    public String deletePost() {
        return "admin/admin";
    }

}
