package com.li.service;


import com.li.dao.User;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

public interface UserService {
    public User findUserByUserName(String userName);
    public Map<String, Object> registerUserAccount(User user);
}
