package com.li.service.impl;

import com.li.dao.User;
import com.li.dao.mapper.UserMapper;
import com.li.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    @Autowired
    UserMapper userMapper;

    @Override
    public User findUserByUserName(String userName) {
        return userMapper.findByUserName(userName);
    }

    @Override
    public Map<String, Object> registerUserAccount(User userDto) {
        Map<String, Object> attributes = new HashMap<>();

        // save newly registered user
        User user = new User();

        user.setPassword(bCryptPasswordEncoder.encode(userDto.getPassword()));  //保存时应该将密码编码

//		user.setPassword(userDto.getPassword());
        user.setUserName(userDto.getUserName());
//        user.activated(true);
        user.setRoles("USER");
//        user.setConfirmationToken(UUID.randomUUID().toString());

        // save new user and get number of affected row
//        logger.debug("用户注册");
        int affectedRow = userMapper.save(user);
//        logger.debug("用户注册成功");
        // publish registration event
//        String appUrl = "http://" + request.getServerName() + ":" + request.getServerPort();
//        Locale locale = request.getLocale();
//        OnRegistrationCompleteEvent event = new OnRegistrationCompleteEvent(user.getUserName(), appUrl, locale);
//        this.evenPublisher.publishEvent(event);

        // populate attributes
        String registrationResult = affectedRow == 1 ? "success" : "failure";
        attributes.put("userRegistrationResult", registrationResult);
        return attributes;
    }
}
